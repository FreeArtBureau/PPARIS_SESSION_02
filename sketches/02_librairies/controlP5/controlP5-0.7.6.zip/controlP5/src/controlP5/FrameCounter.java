package controlP5;

class FrameCounter {
	// a Label based frame counter with current and average frame counts.
}
